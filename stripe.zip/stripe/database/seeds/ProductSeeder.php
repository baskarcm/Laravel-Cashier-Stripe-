<?php

use Illuminate\Database\Seeder;
use App\Product;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	$products = array('Apple','Orange','Pineapple');
    	$prices = array('150','75','50');
        for ($i=0; $i < 3; $i++) { 
	    	Product::create([
	            'product' => $products[$i],
	            'price' => $prices[$i]
	        ]);
    	}
    }
}
