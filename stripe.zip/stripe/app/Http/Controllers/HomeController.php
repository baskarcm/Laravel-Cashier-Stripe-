<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
class HomeController extends Controller
{
    public function index(){
    	$products = Product::get();
    	return view('welcome',compact('products'));
    }

    public function payment(Request $request){
    	$product = $request->input('product');
    	$price = $request->input('price');
    	\Stripe\Stripe::setApiKey(ENV('STRIPE_SECRET'));

		$payments = \Stripe\Token::create([
		 'card' => [
		    'number' => '4242424242424242',
		    'exp_month' => 2,
		    'exp_year' => 2022,
		    'cvc' => '314',
		  ],
		]);
		$payment = \Stripe\Charge::create([
		  'amount' => $price,
		  'currency' => 'inr',
          "source" => $payments->id,
	        "description" => "Making test payment." 

		]);
		return redirect($payment->receipt_url);
    }
}
